def say_hello(name):
    print("Hello, " + name)

user_name = input("What is your name? ")

say_hello(user_name)
