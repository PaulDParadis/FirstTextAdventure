print("Escape from Cave Terror!")
action_input = input('Action: ')
print(action_input)
