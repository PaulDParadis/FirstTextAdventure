user_input = input("Type some text: ")
print(user_input)
