print("Escape from Cave Terror!")
