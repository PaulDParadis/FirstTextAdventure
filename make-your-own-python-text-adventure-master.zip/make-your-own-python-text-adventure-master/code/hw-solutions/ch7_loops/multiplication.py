for i in range(1, 11):
    line = ""
    for j in range(1, 11):
        line = line + str(i * j) + " "
    print(line)
