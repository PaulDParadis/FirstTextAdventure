letters = ['alpha','beta','gamma','delta','epsilon','zeta','eta']
for i, letter in enumerate(letters):
    if i % 3 == 0:
        print(letter)
