favorites = []
favorites.append(input("What is your favorite food? "))
favorites.append(input("What is your 2nd favorite food? "))
favorites.append(input("What is your 3rd favorite food? "))
