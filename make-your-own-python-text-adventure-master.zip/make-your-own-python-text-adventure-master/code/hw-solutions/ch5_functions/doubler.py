def double(a):
    return a * 2

print(double(12345))
print(double(1.57))
