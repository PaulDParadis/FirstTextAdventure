print(input("Type some text: "))
